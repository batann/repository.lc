xbmc-adult
==========

main repo for Frodo, Gotham, Helix, Isengard, Jarvis, Krypton, Leia and Matrix

See https://github.com/xbmc-adult/xbmc-adult/wiki/Devel before sending pull
requests

See the [wiki](https://github.com/xbmc-adult/xbmc-adult/wiki) for all other information.
